package week4.day1;

public abstract class Canara implements RBI {
	
	public void carLoan() {
		System.out.println("Car loan upto 10 lakhs");

	}
	
	public abstract void houseLoan();
	
	
	
	

}
