package week4.day1;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class LaunchChrome {
	public void launchBrowser() {
		ChromeDriver driver=new ChromeDriver();
	   
}

}
