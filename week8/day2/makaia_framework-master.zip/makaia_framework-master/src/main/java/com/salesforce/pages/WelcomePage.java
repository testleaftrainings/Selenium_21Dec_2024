package com.salesforce.pages;

public class WelcomePage {

}
