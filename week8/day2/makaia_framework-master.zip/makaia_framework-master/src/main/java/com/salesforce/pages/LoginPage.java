package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

	public LoginPage enterUsername(String userName) {
		WebElement usernameReference = locateElement("username");
		type(usernameReference, userName);
		reportStep("username "+userName+" is entered sucessfully", "pass");
//		type(locateElement("username"), "gokul.sekar@testleaf.com");\
		return this;
	}
	
	public LoginPage enterPassword(String password) {
	clearAndType(locateElement(Locators.ID, "password"), password);
	reportStep("password "+password+" is entered sucessfully", "pass");
	return this;
	}
	
	public WelcomePage clickLogin() {
		click(locateElement(Locators.ID, "Login"));
		reportStep("login button clicked sucessful", "pass");
		return new WelcomePage();
	}
	
}
