package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class TC_001_Verify_Login extends ProjectSpecificMethods{

	@BeforeTest
	public void setValues() {
		testcaseName = "VerifyLogin";
		testDescription ="Verify Login functionality with positive data";
		authors="Gokul";
		category ="Regression";
		excelFileName="SalesforceLogin";
	}
	
	@Test(dataProvider = "fetchData")
	public void runSalesforceLogin(String uname, String pwd) {
		new LoginPage()
		.enterUsername(uname)
		.enterPassword(pwd)
		.clickLogin();
	}
	
}
