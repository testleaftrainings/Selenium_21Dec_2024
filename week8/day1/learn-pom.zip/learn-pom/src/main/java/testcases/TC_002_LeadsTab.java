package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002_LeadsTab extends BaseClass{

	@Test
	public void runLeadsTab() {
		System.out.println("driver value in leadstab testcase is "+driver);
		new LoginPage(driver)
		.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadTab();
		
	}
	
	
}
