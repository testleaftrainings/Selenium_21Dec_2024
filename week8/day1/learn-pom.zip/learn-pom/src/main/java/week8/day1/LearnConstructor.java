package week8.day1;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class LearnConstructor {

	// constructor is a special method is java
	// constructor syntax is accessModifer ClassName(inputArgs){}
	//If the constructor is not defined compiler will create default constructor
	// if user created constructor compiler will not create default constructor
	
	
	public LearnConstructor() {
//		this(3);
		System.out.println("This is zero argument constructor");
	}
	
	public LearnConstructor(int x) {
		x++;
		System.out.println("This is parameterized constructor and the x value is "+x);
	}
	
	
	// method signature will be accessModifier returnType methodName(input args){}
	public static void main(String[] args) {
		
		LearnConstructor lc = new LearnConstructor(7);
//		ChromeOptions option = new ChromeOptions();
//		option.addArguments("--start-maximized");
//		ChromeDriver driver = new ChromeDriver(option);
//		Select select = new Select();
		
	}
	
	
	
}
