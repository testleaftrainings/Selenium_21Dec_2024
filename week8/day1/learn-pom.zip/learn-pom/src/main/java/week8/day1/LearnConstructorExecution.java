package week8.day1;

public class LearnConstructorExecution extends LearnConstructor{

	public LearnConstructorExecution() {
		System.out.println("This is sub class constructor");
	}
	
	public static void main(String[] args) {
		LearnConstructorExecution lce = new LearnConstructorExecution();
	}
	
	
}
