package week8.day1;

import java.io.File;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) {
		
		File reportPath = new File("./report/result.html");
		
		ExtentHtmlReporter reporter = new ExtentHtmlReporter(reportPath);
		
		ExtentReports extent = new ExtentReports();
		
		extent.attachReporter(reporter);
		
		ExtentTest test = extent.createTest("Testcase name");
		
		test.assignAuthor("Gokul");
		
		test.assignCategory("regression");
		
		test.pass("enter username is successful");
		
		test.fail("unable the enter the value in password field");
		
		ExtentTest test2 = extent.createTest("TC_001_Login" , "Login testcase with valid test data");
		test2.assignAuthor("Babu");
		test2.assignCategory("Smoke");
		test2.pass("The username entered sucessfully as demosalesmanager");
		test2.pass("The password entered sucessfully as crmsfa");
		test2.pass("The login button is clicked sucessful");
		
		extent.flush();
		System.out.println("The report is generated successfully");
	}
	
}
