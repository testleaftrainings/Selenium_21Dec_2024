package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class LeadPage extends BaseClass {

	public LeadPage(RemoteWebDriver driver) {
		this.driver = driver;
	}

}
